import fs from 'fs';
import path from 'path';
import { spawn } from 'child_process';

const activeJobs = new Map();
const downloadsDir = path.resolve(process.cwd(), 'temp_downloads');

if (!fs.existsSync(downloadsDir)) {
  fs.mkdirSync(downloadsDir, { recursive: true });
}

// Zero server storage: purge any leftover media files on startup
try {
  const existingFiles = fs.readdirSync(downloadsDir);
  for (const f of existingFiles) {
    if (f !== 'support_messages.json') {
      try { fs.unlinkSync(path.join(downloadsDir, f)); } catch {}
    }
  }
} catch {}

// Purge media jobs immediately after transfer or if older than 2 minutes
setInterval(() => {
  const now = Date.now();
  for (const [jobId, job] of activeJobs.entries()) {
    if (now - job.createdAt > 2 * 60 * 1000) {
      if (job.actualPath && fs.existsSync(job.actualPath)) {
        try { fs.unlinkSync(job.actualPath); } catch {}
      }
      activeJobs.delete(jobId);
    }
  }
  // Also clean unreferenced temporary media fragments
  try {
    const files = fs.readdirSync(downloadsDir);
    for (const f of files) {
      if (f !== 'support_messages.json') {
        const full = path.join(downloadsDir, f);
        const stat = fs.statSync(full);
        if (now - stat.mtimeMs > 2 * 60 * 1000) {
          try { fs.unlinkSync(full); } catch {}
        }
      }
    }
  } catch {}
}, 60 * 1000);

/**
 * Validates that an incoming URL is a public, safe HTTP or HTTPS media URL,
 * mitigating Server-Side Request Forgery (SSRF) against internal resources.
 */
export function isValidPublicMediaUrl(inputUrl) {
  if (!inputUrl || typeof inputUrl !== 'string') return false;
  let parsed;
  try {
    parsed = new URL(inputUrl.trim());
  } catch {
    return false;
  }

  // Strictly require http: or https:
  if (parsed.protocol !== 'http:' && parsed.protocol !== 'https:') {
    return false;
  }

  const hostname = parsed.hostname.toLowerCase();

  // Reject empty hostname or credentials embedded in URL
  if (!hostname || parsed.username || parsed.password) {
    return false;
  }

  // Block localhost and standard loopback hostnames
  if (
    hostname === 'localhost' ||
    hostname.endsWith('.localhost') ||
    hostname === '127.0.0.1' ||
    hostname === '0.0.0.0' ||
    hostname === '::1' ||
    hostname === '[::1]'
  ) {
    return false;
  }

  // Block AWS / cloud metadata endpoints
  if (
    hostname === '169.254.169.254' ||
    hostname === 'metadata.google.internal' ||
    hostname === 'instance-data'
  ) {
    return false;
  }

  // Block private IPv4 ranges:
  // 10.0.0.0/8, 172.16.0.0/12, 192.168.0.0/16, 169.254.0.0/16, 127.0.0.0/8, 0.0.0.0/8
  const ipv4Regex = /^(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})$/;
  const ipMatch = hostname.match(ipv4Regex);
  if (ipMatch) {
    const p1 = parseInt(ipMatch[1], 10);
    const p2 = parseInt(ipMatch[2], 10);
    const p3 = parseInt(ipMatch[3], 10);
    const p4 = parseInt(ipMatch[4], 10);

    if (p1 > 255 || p2 > 255 || p3 > 255 || p4 > 255) return false;
    if (p1 === 127 || p1 === 10 || p1 === 0) return false;
    if (p1 === 172 && p2 >= 16 && p2 <= 31) return false;
    if (p1 === 192 && p2 === 168) return false;
    if (p1 === 169 && p2 === 254) return false;
  }

  // Block private IPv6 ranges
  if (
    hostname.startsWith('[fc') ||
    hostname.startsWith('[fd') ||
    hostname.startsWith('[fe80:') ||
    hostname.startsWith('[::')
  ) {
    return false;
  }

  return true;
}

function parseJsonBody(req) {
  return new Promise((resolve, reject) => {
    let body = '';
    req.on('data', chunk => {
      body += chunk;
      if (body.length > 1e6) {
        req.destroy();
        reject(new Error('Request body too large'));
      }
    });
    req.on('end', () => {
      try {
        resolve(body ? JSON.parse(body) : {});
      } catch (err) {
        reject(err);
      }
    });
    req.on('error', reject);
  });
}

/**
 * Spawns yt-dlp using python -m yt_dlp (bypassing Windows AppLocker policy on raw yt-dlp.exe)
 * with graceful fallback to yt-dlp.
 */
export function spawnYtDlp(args) {
  try {
    return spawn('python', ['-m', 'yt_dlp', ...args]);
  } catch {
    return spawn('yt-dlp', args);
  }
}

export function runCommandAsync(cmd, args) {
  return new Promise((resolve, reject) => {
    const proc = spawn(cmd, args);
    let stdout = '';
    let stderr = '';
    proc.stdout?.on('data', d => { stdout += d; });
    proc.stderr?.on('data', d => { stderr += d; });
    proc.on('close', code => {
      if (code === 0) resolve(stdout.trim());
      else reject(new Error(stderr || `Command ${cmd} exited with code ${code}`));
    });
    proc.on('error', reject);
  });
}

function cleanYtDlpError(rawStderr) {
  if (!rawStderr) return null;
  const lines = rawStderr.split('\n');
  const errorLine = lines.reverse().find(l => l.includes('ERROR:'));
  if (errorLine) {
    let msg = errorLine.replace(/^ERROR:\s*(?:\[[^\]]+\]\s*)?/, '').trim();
    msg = msg.replace(/^[^:]+:\s*/, '');
    msg = msg.replace(/;\s*please report this issue on.*$/i, '').trim();
    msg = msg.replace(/Confirm you are on the latest version.*$/i, '').trim();
    if (msg.toLowerCase().includes('no video formats found')) {
      return 'No downloadable media streams found for this video. The content may be private or restricted by the platform.';
    }
    return msg;
  }
  return null;
}

/**
 * Resolve video metadata using yt-dlp
 */
export async function resolveVideo(url, platform = null) {
  return new Promise((resolve) => {
    const args = [
      '--js-runtimes', 'node',
      '--dump-single-json',
      '--no-warnings',
      '--no-playlist',
      '--no-check-certificates',
      '--user-agent', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36',
      url
    ];

    let stdoutData = '';
    let stderrData = '';
    let proc;
    try {
      proc = spawnYtDlp(args);
    } catch {
      return resolve(null);
    }

    const timer = setTimeout(() => {
      try { proc.kill(); } catch {}
      resolve(null);
    }, 75000);

    proc.stdout.on('data', chunk => {
      stdoutData += chunk;
    });

    proc.stderr.on('data', chunk => {
      stderrData += chunk;
    });

    proc.on('error', () => {
      clearTimeout(timer);
      resolve(null);
    });

    proc.on('close', (code) => {
      clearTimeout(timer);
      if (code === 0 && stdoutData) {
        try {
          const info = JSON.parse(stdoutData);
          
          const rawFormats = info.formats || [];
          const videoFormats = [];
          const audioFormats = [];

          const isPortrait = Boolean(info.width && info.height && info.height > info.width);
          const duration = Math.round(info.duration || 60);

          // Map available video heights
          const availableHeights = new Set();
          for (const f of rawFormats) {
            if (f.height && f.height > 0) {
              availableHeights.add(f.height);
            }
          }

          const targetHeights = [2160, 1440, 1080, 720, 480, 360];
          for (const targetH of targetHeights) {
            const hasMatch = Array.from(availableHeights).some(h => h >= targetH);
            if (hasMatch) {
              const calcW = isPortrait
                ? Math.round(targetH * 9 / 16)
                : Math.round(targetH * 16 / 9);
              const label = targetH >= 2160 ? '4K 2160p'
                : targetH >= 1440 ? '2K 1440p'
                : targetH >= 1080 ? '1080p FHD'
                : targetH >= 720 ? '720p HD'
                : targetH >= 480 ? '480p SD'
                : `${targetH}p`;

              const bytesPerSec = targetH >= 2160 ? 900000
                : targetH >= 1440 ? 550000
                : targetH >= 1080 ? 320000
                : targetH >= 720 ? 160000
                : targetH >= 480 ? 80000
                : 45000;

              videoFormats.push({
                id: `mp4-${targetH}p`,
                type: 'video',
                container: 'MP4',
                quality: label,
                resolution: `${calcW}x${targetH}`,
                sizeBytes: Math.round(duration * bytesPerSec),
                fps: targetH >= 1080 ? 60 : 30,
                hasAudio: true,
              });
            }
          }

          // If no tiered heights found, provide native best stream and SD fallback
          if (videoFormats.length === 0) {
            const nativeH = info.height || 720;
            const nativeW = info.width || (isPortrait ? Math.round(nativeH * 9 / 16) : Math.round(nativeH * 16 / 9));
            videoFormats.push(
              { id: 'mp4-best', type: 'video', container: 'MP4', quality: `${nativeH}p`, resolution: `${nativeW}x${nativeH}`, sizeBytes: Math.round(duration * 180000), fps: 30, hasAudio: true }
            );
            if (nativeH > 480) {
              videoFormats.push(
                { id: 'mp4-480p', type: 'video', container: 'MP4', quality: '480p SD', resolution: isPortrait ? '270x480' : '854x480', sizeBytes: Math.round(duration * 75000), fps: 30, hasAudio: true }
              );
            }
          }

          // Audio formats
          audioFormats.push(
            { id: 'mp3-320', type: 'audio', container: 'MP3', quality: '320', bitrate: '320kbps', sizeBytes: Math.round(duration * 40000), sampleRate: '48kHz' },
            { id: 'mp3-192', type: 'audio', container: 'MP3', quality: '192', bitrate: '192kbps', sizeBytes: Math.round(duration * 24000), sampleRate: '44.1kHz' },
            { id: 'mp3-128', type: 'audio', container: 'MP3', quality: '128', bitrate: '128kbps', sizeBytes: Math.round(duration * 16000), sampleRate: '44.1kHz' },
            { id: 'm4a-128', type: 'audio', container: 'M4A', quality: '128', bitrate: '128kbps AAC', sizeBytes: Math.round(duration * 16000), sampleRate: '44.1kHz' }
          );

          let thumb = info.thumbnail || '';
          if (!thumb && Array.isArray(info.thumbnails) && info.thumbnails.length > 0) {
            thumb = info.thumbnails[info.thumbnails.length - 1]?.url || '';
          }

          resolve({
            success: true,
            source: info.extractor_key || platform || 'Web',
            title: info.title || 'Online Video',
            author: info.uploader || info.channel || info.creator || info.uploader_id || 'Creator',
            thumbnail: thumb,
            duration: duration,
            originalUrl: url,
            formats: [...videoFormats, ...audioFormats],
          });
        } catch {
          resolve(null);
        }
      } else {
        resolve(null);
      }
    });
  });
}

/**
 * Fallback metadata resolver using public OpenGraph / HTML metadata
 */
export async function resolvePageMetadata(url, platform = null) {
  try {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 10000);
    const resp = await fetch(url, {
      signal: controller.signal,
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'Accept-Language': 'en-US,en;q=0.9',
      },
    });
    clearTimeout(timeout);
    if (!resp.ok) return null;
    const html = await resp.text();

    const getMeta = (prop) => {
      const match = html.match(new RegExp(`<meta\\s+(?:property|name)=["'](?:og:|twitter:)?${prop}["']\\s+content=["']([^"']+)["']`, 'i'))
        || html.match(new RegExp(`<meta\\s+content=["']([^"']+)["']\\s+(?:property|name)=["'](?:og:|twitter:)?${prop}["']`, 'i'));
      return match ? match[1] : null;
    };

    const ogTitle = getMeta('title');
    const ogImage = getMeta('image');
    const ogSite = getMeta('site_name') || platform;
    const titleTagMatch = html.match(/<title[^>]*>([^<]+)<\/title>/i);
    const rawTitle = ogTitle || (titleTagMatch ? titleTagMatch[1] : null);

    if (rawTitle && rawTitle.trim()) {
      const cleanTitle = rawTitle.replace(/[\r\n\t]/g, ' ').replace(/\s+/g, ' ').trim();
      const lowerTitle = cleanTitle.toLowerCase();

      // Ignore generic 404 error pages or missing video titles
      if (
        cleanTitle === 'YouTube' ||
        cleanTitle === '- YouTube' ||
        lowerTitle.includes('page not found') ||
        lowerTitle.includes('404 not found') ||
        lowerTitle.includes('video unavailable') ||
        lowerTitle === 'instagram' ||
        lowerTitle === 'tiktok' ||
        lowerTitle === 'reddit'
      ) {
        return null;
      }

      const cleanAuthor = ogSite || 'Creator';
      const thumbnail = ogImage || '';

      return {
        success: true,
        source: platform ? (platform.charAt(0).toUpperCase() + platform.slice(1)) : 'Online Video',
        title: cleanTitle,
        author: cleanAuthor,
        thumbnail,
        duration: 60,
        originalUrl: url,
        formats: [
          { id: 'mp4-1080p', type: 'video', container: 'MP4', quality: '1080p FHD', resolution: '1920x1080', sizeBytes: 36700160, fps: 60, hasAudio: true },
          { id: 'mp4-720p',  type: 'video', container: 'MP4', quality: '720p HD',   resolution: '1280x720',  sizeBytes: 18874368, fps: 30, hasAudio: true },
          { id: 'mp4-480p',  type: 'video', container: 'MP4', quality: '480p SD',   resolution: '854x480',   sizeBytes: 9437184,  fps: 30, hasAudio: true },
          { id: 'mp3-320',   type: 'audio', container: 'MP3', quality: '320',       bitrate: '320kbps',      sizeBytes: 4815744,  sampleRate: '48kHz' },
          { id: 'mp3-192',   type: 'audio', container: 'MP3', quality: '192',       bitrate: '192kbps',      sizeBytes: 2831155,  sampleRate: '44.1kHz' },
          { id: 'mp3-128',   type: 'audio', container: 'MP3', quality: '128',       bitrate: '128kbps',      sizeBytes: 1887436,  sampleRate: '44.1kHz' },
          { id: 'm4a-128',   type: 'audio', container: 'M4A', quality: '128',       bitrate: '128kbps AAC',  sizeBytes: 1887436,  sampleRate: '44.1kHz' },
        ],
      };
    }
  } catch {
    // ignore
  }
  return null;
}

/**
 * Vite plugin exposing the VidLoader backend API endpoints:
 * - POST /api/resolve
 * - POST /api/process
 * - GET  /api/process/:jobId
 * - GET  /api/download/:jobId
 */
export function vidloaderBackendPlugin() {
  return {
    name: 'vidloader-backend',
    configureServer(server) {
      server.middlewares.use(async (req, res, next) => {
        const url = req.url || '';
        if (!url.startsWith('/api')) {
          return next();
        }

        if (res.headersSent) {
          return;
        }

        // 1. POST /api/resolve
        if (url === '/api/resolve' && req.method === 'POST') {
          try {
            const body = await parseJsonBody(req);
            const targetUrl = (body.url || '').trim();
            const platform = body.platform || null;

            if (!targetUrl) {
              res.statusCode = 400;
              res.setHeader('Content-Type', 'application/json');
              return res.end(JSON.stringify({ success: false, message: 'URL is required' }));
            }

            if (!isValidPublicMediaUrl(targetUrl)) {
              res.statusCode = 400;
              res.setHeader('Content-Type', 'application/json');
              return res.end(JSON.stringify({
                success: false,
                message: 'Invalid URL. Please enter a valid, public HTTP or HTTPS video link.',
              }));
            }

            // 1. Attempt yt-dlp resolution
            const resolved = await resolveVideo(targetUrl, platform);
            if (resolved) {
              res.statusCode = 200;
              res.setHeader('Content-Type', 'application/json');
              return res.end(JSON.stringify(resolved));
            }

            // 2. Attempt lightweight HTML OpenGraph / Meta tag resolution
            const ogResolved = await resolvePageMetadata(targetUrl, platform);
            if (ogResolved) {
              res.statusCode = 200;
              res.setHeader('Content-Type', 'application/json');
              return res.end(JSON.stringify(ogResolved));
            }

            // 3. Inform user clearly if URL cannot be fetched
            res.statusCode = 422;
            res.setHeader('Content-Type', 'application/json');
            return res.end(JSON.stringify({
              success: false,
              message: 'Could not fetch media information from this URL. Please verify the URL is public, accessible, and not private or age-restricted.',
            }));
          } catch (err) {
            res.statusCode = 500;
            res.setHeader('Content-Type', 'application/json');
            return res.end(JSON.stringify({ success: false, message: err.message }));
          }
        }

        // 2. POST /api/process
        if (url === '/api/process' && req.method === 'POST') {
          try {
            const body = await parseJsonBody(req);
            const { url: targetUrl, format = 'mp4', quality = '720p HD', title = 'video', formatId = '' } = body;

            if (!targetUrl) {
              res.statusCode = 400;
              res.setHeader('Content-Type', 'application/json');
              return res.end(JSON.stringify({ success: false, message: 'URL is required' }));
            }

            if (!isValidPublicMediaUrl(targetUrl)) {
              res.statusCode = 400;
              res.setHeader('Content-Type', 'application/json');
              return res.end(JSON.stringify({
                success: false,
                message: 'Invalid URL. Please enter a valid, public HTTP or HTTPS video link.',
              }));
            }

            const isM4A = format.toLowerCase() === 'm4a' || formatId.includes('m4a');
            const isAudio = isM4A || format.toLowerCase() === 'mp3' || formatId.includes('audio') || formatId.includes('mp3');
            const ext = isM4A ? 'm4a' : isAudio ? 'mp3' : 'mp4';
            const jobId = `job_${Date.now()}_${Math.floor(Math.random() * 10000)}`;

            const cleanTitle = (title || 'video')
              .replace(/[^a-zA-Z0-9\s_-]/g, '')
              .trim()
              .replace(/\s+/g, '_')
              .slice(0, 40) || 'Video';
            const cleanQuality = (quality || 'HD').replace(/[^a-zA-Z0-9]/g, '_');
            const downloadFilename = `VidLoader_${cleanTitle}_${cleanQuality}.${ext}`;
            const targetOutputFile = path.join(downloadsDir, `${jobId}.${ext}`);

            const job = {
              id: jobId,
              url: targetUrl,
              format: ext,
              quality,
              title,
              filename: downloadFilename,
              targetOutputFile,
              actualPath: null,
              fileSize: 0,
              status: 'queued',
              progress: 10,
              error: null,
              createdAt: Date.now(),
            };

            activeJobs.set(jobId, job);

            // Respond immediately with jobId
            res.statusCode = 200;
            res.setHeader('Content-Type', 'application/json');
            res.end(JSON.stringify({
              success: true,
              jobId,
              message: 'Processing started',
            }));

            // Launch background download task outside response lifecycle
            setTimeout(() => {
              try {
                startBackgroundDownload(job);
              } catch (bgErr) {
                console.error(`[VidLoader Job ${jobId}] Start error:`, bgErr);
              }
            }, 10);
            return;
          } catch (err) {
            if (!res.headersSent) {
              res.statusCode = 500;
              res.setHeader('Content-Type', 'application/json');
              return res.end(JSON.stringify({ success: false, message: err.message }));
            }
          }
        }

        // 3. GET /api/process/:jobId
        if (url.startsWith('/api/process/') && req.method === 'GET') {
          const jobId = url.replace('/api/process/', '').split('?')[0];
          const job = activeJobs.get(jobId);

          if (res.headersSent) return;

          if (!job) {
            res.statusCode = 404;
            res.setHeader('Content-Type', 'application/json');
            return res.end(JSON.stringify({ status: 'failed', message: 'Job not found' }));
          }

          if (res.headersSent) return;
          res.statusCode = 200;
          res.setHeader('Content-Type', 'application/json');
          return res.end(JSON.stringify({
            status: job.status,
            progress: job.progress,
            jobId: job.id,
            downloadUrl: job.status === 'completed' ? `/api/download/${job.id}` : null,
            fileInfo: {
              filename: job.filename,
              format: job.format,
              quality: job.quality,
              sizeBytes: job.fileSize,
            },
            error: job.error,
          }));
        }

        // 4. GET /api/download/:jobId (Direct to User Device, Zero Server Storage)
        if (url.startsWith('/api/download/') && req.method === 'GET') {
          const jobId = url.replace('/api/download/', '').split('?')[0];
          const job = activeJobs.get(jobId);

          if (!job || !job.actualPath || !fs.existsSync(job.actualPath)) {
            res.statusCode = 404;
            res.setHeader('Content-Type', 'text/plain');
            return res.end('File already transferred to device.');
          }

          const filePath = job.actualPath;
          const stat = fs.statSync(filePath);
          const mimeType = job.format === 'mp3' ? 'audio/mpeg' : job.format === 'm4a' ? 'audio/mp4' : 'video/mp4';
          const safeFilename = (job.filename || 'video.mp4')
            .replace(/[^a-zA-Z0-9._-]/g, '_')
            .replace(/_+/g, '_');

          res.statusCode = 200;
          res.setHeader('Content-Type', mimeType);
          res.setHeader('Content-Length', stat.size);
          res.setHeader('Content-Disposition', `attachment; filename="${safeFilename}"; filename*=UTF-8''${encodeURIComponent(job.filename || safeFilename)}`);

          const readStream = fs.createReadStream(filePath);
          readStream.pipe(res);

          // Zero Server Storage: erase media from server disk immediately after delivery to user's device!
          let hasCleaned = false;
          const cleanImmediately = () => {
            if (hasCleaned) return;
            hasCleaned = true;
            setTimeout(() => {
              try {
                if (fs.existsSync(filePath)) {
                  fs.unlinkSync(filePath);
                  console.log(`[VidLoader Zero-Storage] File permanently deleted from server: ${filePath}`);
                }
                activeJobs.delete(jobId);
              } catch {}
            }, 600);
          };

          res.on('finish', cleanImmediately);
          res.on('close', cleanImmediately);
          return;
        }

        // 5. GET /api/thumbnail
        if (url.startsWith('/api/thumbnail') && req.method === 'GET') {
          try {
            const parsed = new URL(req.url, 'http://localhost');
            const imgUrl = parsed.searchParams.get('url');
            const customTitle = parsed.searchParams.get('title') || 'Thumbnail';

            if (!imgUrl || !isValidPublicMediaUrl(imgUrl)) {
              res.statusCode = 400;
              res.setHeader('Content-Type', 'application/json');
              return res.end(JSON.stringify({ success: false, message: 'A valid public HTTP/HTTPS image URL is required' }));
            }

            let imageBuffer;
            let contentType = 'image/jpeg';
            try {
              const response = await fetch(imgUrl);
              if (response.ok) {
                contentType = response.headers.get('content-type') || 'image/jpeg';
                const arrayBuffer = await response.arrayBuffer();
                imageBuffer = Buffer.from(arrayBuffer);
              }
            } catch (fetchErr) {
              console.warn('[VidLoader Thumbnail] Remote fetch failed, using fallback cover:', fetchErr.message);
            }

            if (!imageBuffer) {
              const fallbackCover = path.resolve(process.cwd(), 'public', 'demo-thumb.jpg');
              if (fs.existsSync(fallbackCover)) {
                imageBuffer = fs.readFileSync(fallbackCover);
                contentType = 'image/jpeg';
              } else {
                res.statusCode = 502;
                res.setHeader('Content-Type', 'application/json');
                return res.end(JSON.stringify({ success: false, message: 'Failed to fetch thumbnail image' }));
              }
            }

            const ext = contentType.includes('png') ? 'png' : contentType.includes('webp') ? 'webp' : 'jpg';
            const cleanTitle = customTitle.replace(/[^a-zA-Z0-9\s_-]/g, '').trim().replace(/\s+/g, '_') || 'Thumbnail';
            const filename = `VidLoader_Thumbnail_${cleanTitle}.${ext}`;

            res.statusCode = 200;
            res.setHeader('Content-Type', contentType);
            res.setHeader('Content-Disposition', `attachment; filename="${encodeURIComponent(filename)}"`);
            return res.end(imageBuffer);
          } catch (err) {
            res.statusCode = 500;
            res.setHeader('Content-Type', 'application/json');
            return res.end(JSON.stringify({ success: false, message: err.message }));
          }
        }

        // 6. POST /api/contact
        if (url === '/api/contact' && req.method === 'POST') {
          try {
            const body = await parseJsonBody(req);
            const { name, email, category, subject, message } = body;
            const cleanName = (name || '').trim().slice(0, 100);
            const cleanEmail = (email || '').trim().slice(0, 150);
            const cleanCategory = (category || 'Support').trim().slice(0, 50);
            const cleanSubject = (subject || 'General Inquiry').trim().slice(0, 200);
            const cleanMessage = (message || '').trim().slice(0, 5000);

            const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            if (!cleanName || !cleanEmail || !cleanMessage || !emailRegex.test(cleanEmail)) {
              res.statusCode = 400;
              res.setHeader('Content-Type', 'application/json');
              return res.end(JSON.stringify({
                success: false,
                message: 'Please provide a valid name, email address, and message.',
              }));
            }

            const inquiry = {
              id: `msg_${Date.now()}`,
              name: cleanName,
              email: cleanEmail,
              category: cleanCategory,
              subject: cleanSubject,
              message: cleanMessage,
              receivedAt: new Date().toISOString()
            };
            const contactLogPath = path.join(downloadsDir, 'support_messages.json');
            let messages = [];
            if (fs.existsSync(contactLogPath)) {
              try { messages = JSON.parse(fs.readFileSync(contactLogPath, 'utf8')); } catch {}
            }
            messages.push(inquiry);
            fs.writeFileSync(contactLogPath, JSON.stringify(messages, null, 2));

            res.statusCode = 200;
            res.setHeader('Content-Type', 'application/json');
            return res.end(JSON.stringify({ success: true, message: 'Message recorded successfully', id: inquiry.id }));
          } catch (err) {
            res.statusCode = 500;
            res.setHeader('Content-Type', 'application/json');
            return res.end(JSON.stringify({ success: false, message: err.message }));
          }
        }

        // 7. GET /api/download-pc-launcher
        if (url === '/api/download-pc-launcher' && req.method === 'GET') {
          const launcherPath = path.resolve(process.cwd(), 'VidLoader-PC-Launcher.bat');
          if (fs.existsSync(launcherPath)) {
            res.statusCode = 200;
            res.setHeader('Content-Type', 'application/x-bat');
            res.setHeader('Content-Disposition', 'attachment; filename="VidLoader-PC-Launcher.bat"');
            return fs.createReadStream(launcherPath).pipe(res);
          }
          res.statusCode = 404;
          return res.end('Launcher file not found');
        }

        // 7b. GET /api/download-installer?platform=windows|mac|linux|android|ios
        if (url.startsWith('/api/download-installer') && req.method === 'GET') {
          const parsedUrl = new URL(req.url, 'http://localhost');
          const platform = (parsedUrl.searchParams.get('platform') || 'windows').toLowerCase();
          const installerMap = {
            windows: { file: 'VidLoader-Setup.exe', type: 'application/vnd.microsoft.portable-executable' },
            mac: { file: 'VidLoader-macOS.dmg', type: 'application/x-apple-diskimage' },
            macos: { file: 'VidLoader-macOS.dmg', type: 'application/x-apple-diskimage' },
            linux: { file: 'VidLoader-Linux.AppImage', type: 'application/x-executable' },
            android: { file: 'VidLoader-v2.4.apk', type: 'application/vnd.android.package-archive' },
            ios: { file: 'VidLoader-iOS.mobileconfig', type: 'application/x-apple-aspen-config' },
          };
          const target = installerMap[platform] || installerMap.windows;
          const targetPath = path.resolve(process.cwd(), 'public', 'downloads', target.file);

          if (fs.existsSync(targetPath)) {
            res.statusCode = 200;
            res.setHeader('Content-Type', target.type);
            res.setHeader('Content-Disposition', `attachment; filename="${target.file}"`);
            res.setHeader('Cache-Control', 'no-cache, no-store, must-revalidate');
            return fs.createReadStream(targetPath).pipe(res);
          }
          res.statusCode = 404;
          res.setHeader('Content-Type', 'application/json');
          return res.end(JSON.stringify({ success: false, error: 'Installer file not found' }));
        }

        // 8. GET /api/system-status
        if (url === '/api/system-status' && req.method === 'GET') {
          res.statusCode = 200;
          res.setHeader('Content-Type', 'application/json');
          return res.end(JSON.stringify({
            ok: true,
            server: 'VidLoader Local Engine',
            ytdlp: true,
            ffmpeg: true,
            port: 5173,
            version: '2.4.0',
            os: process.platform,
          }));
        }

        res.statusCode = 404;
        res.setHeader('Content-Type', 'application/json');
        return res.end(JSON.stringify({ success: false, error: 'API endpoint not found', path: url }));
      });
    },
  };
}

/**
 * Executes yt-dlp to download and convert the requested video/audio directly from the EXACT URL.
 * Automatically retries with universal streams and remuxes container when needed.
 * Never serves fake sample files.
 */
function startBackgroundDownload(job) {
  const isAudio = job.format === 'mp3' || job.format === 'm4a';
  const targetExt = isAudio ? (job.format === 'm4a' ? 'm4a' : 'mp3') : 'mp4';
  const templatePath = path.join(downloadsDir, `${job.id}.%(ext)s`);

  // Parse target height from quality label
  let height = null;
  const matchH = (job.quality || '').match(/(\d{3,4})p?/i);
  if (matchH) {
    height = parseInt(matchH[1], 10);
  } else if ((job.quality || '').includes('2160') || (job.quality || '').includes('4K')) {
    height = 2160;
  } else if ((job.quality || '').includes('1440') || (job.quality || '').includes('2K')) {
    height = 1440;
  } else if ((job.quality || '').includes('1080') || (job.quality || '').includes('FHD')) {
    height = 1080;
  } else if ((job.quality || '').includes('720') || (job.quality || '').includes('HD')) {
    height = 720;
  } else if ((job.quality || '').includes('480')) {
    height = 480;
  } else if ((job.quality || '').includes('360')) {
    height = 360;
  }

  const baseArgs = [
    '--js-runtimes', 'node',
    '--no-playlist',
    '--no-check-certificates',
    '--no-warnings',
    '--newline',
    '--user-agent', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36',
  ];

  let initialArgs = [];
  if (isAudio) {
    let audioQualityArg = '0';
    const bitrateMatch = (job.quality || '').match(/(\d+)\s*(?:kbps|k)?/i);
    if (bitrateMatch) {
      audioQualityArg = `${bitrateMatch[1]}K`;
    }

    initialArgs = [
      ...baseArgs,
      '-x',
      '--audio-format', targetExt,
      '--audio-quality', audioQualityArg,
      '-o', templatePath,
      job.url,
    ];
  } else {
    let formatSpec = 'best[ext=mp4]/bestvideo+bestaudio/best';
    if (height) {
      formatSpec = `best[height<=?${height}][ext=mp4]/bestvideo[height<=?${height}]+bestaudio/best[height<=?${height}]/best`;
    }

    initialArgs = [
      ...baseArgs,
      '-f', formatSpec,
      '--merge-output-format', 'mp4',
      '-o', templatePath,
      job.url,
    ];
  }

  job.status = 'downloading';
  job.progress = 15;

  console.log(`[VidLoader Job ${job.id}] Starting download: ${job.url} (${job.format}, ${job.quality})`);

  function executeDownload(args, isRetry = false) {
    console.log(`[VidLoader Job ${job.id}] Executing with args:`, JSON.stringify(args));
    let proc;
    try {
      proc = spawnYtDlp(args);
    } catch (spawnErr) {
      console.error(`[VidLoader Job ${job.id}] Spawn error:`, spawnErr);
      job.status = 'failed';
      job.error = 'Download engine process could not be launched on the system.';
      return;
    }

    let downloadStreamsCount = 0;
    let stderrData = '';

    proc.stdout.on('data', (data) => {
      const text = data.toString();

      // Detect stream transitions (e.g. video completed, audio stream starting)
      if (text.includes('Destination:') || text.includes('[download] Destination:')) {
        downloadStreamsCount++;
      }

      const match = text.match(/\[download\]\s+(\d+(?:\.\d+)?)%/);
      if (match) {
        const rawPct = parseFloat(match[1]);
        let calculatedPct = 15;

        // Smoothly scale two-stream downloads (stream 1: 15-75%, stream 2: 75-94%)
        if (downloadStreamsCount > 1) {
          calculatedPct = Math.min(94, Math.round(75 + (rawPct * 0.19)));
        } else {
          calculatedPct = Math.min(75, Math.max(15, Math.round(15 + (rawPct * 0.60))));
        }

        // STRICT MONOTONICITY GUARD: Progress percentage can NEVER decrease
        job.progress = Math.max(job.progress || 15, calculatedPct);
        job.status = 'downloading';
      } else if (text.includes('[Merger]') || text.includes('[ExtractAudio]') || text.includes('[Fixup]')) {
        job.status = 'processing';
        job.progress = Math.max(job.progress || 15, 96);
      }
    });


    proc.stderr.on('data', (data) => {
      stderrData += data.toString();
    });

    proc.on('close', async (code) => {
      if (code === 0) {
        try {
          const files = fs.readdirSync(downloadsDir).filter(f => f.startsWith(job.id));
          const validFiles = files.filter(f => !f.endsWith('.part') && !f.endsWith('.ytdl') && !f.endsWith('.temp') && !f.endsWith('.aria2'));

          if (validFiles.length > 0) {
            const exactMatch = validFiles.find(f => f.endsWith(`.${targetExt}`)) || validFiles[0];
            let currentPath = path.join(downloadsDir, exactMatch);

            // If requested video is not .mp4, remux cleanly using ffmpeg
            if (!isAudio && !exactMatch.endsWith('.mp4')) {
              const destMp4 = path.join(downloadsDir, `${job.id}.mp4`);
              try {
                job.status = 'processing';
                job.progress = 98;
                await runCommandAsync('ffmpeg', [
                  '-y',
                  '-i', currentPath,
                  '-c', 'copy',
                  destMp4
                ]);
                if (fs.existsSync(destMp4) && fs.statSync(destMp4).size > 1000) {
                  try { fs.unlinkSync(currentPath); } catch {}
                  currentPath = destMp4;
                }
              } catch (remuxErr) {
                console.warn(`[VidLoader Job ${job.id}] Remux copy warning, trying ultrafast transcode:`, remuxErr.message);
                try {
                  await runCommandAsync('ffmpeg', [
                    '-y',
                    '-i', currentPath,
                    '-c:v', 'libx264',
                    '-preset', 'ultrafast',
                    '-c:a', 'aac',
                    destMp4
                  ]);
                  if (fs.existsSync(destMp4) && fs.statSync(destMp4).size > 1000) {
                    try { fs.unlinkSync(currentPath); } catch {}
                    currentPath = destMp4;
                  }
                } catch (transcodeErr) {
                  console.error(`[VidLoader Job ${job.id}] Transcode failed:`, transcodeErr.message);
                }
              }
            }

            job.actualPath = currentPath;
            job.fileSize = fs.statSync(currentPath).size;
            job.status = 'completed';
            job.progress = 100;
            console.log(`[VidLoader Job ${job.id}] Successfully completed: ${job.fileSize} bytes at ${currentPath}`);
            return;
          }
        } catch (postErr) {
          console.error(`[VidLoader Job ${job.id}] Post-download error:`, postErr);
        }
      }

      // If initial format-specific download fails, retry once with universal best stream
      if (!isRetry) {
        console.warn(`[VidLoader Job ${job.id}] Initial download attempt exited with code ${code}:`, stderrData, `retrying with universal stream...`);
        const retryArgs = isAudio
          ? [
              ...baseArgs,
              '-x',
              '--audio-format', targetExt,
              '-o', templatePath,
              job.url,
            ]
          : [
              ...baseArgs,
              '-f', 'best[ext=mp4]/bestvideo+bestaudio/best',
              '--merge-output-format', 'mp4',
              '-o', templatePath,
              job.url,
            ];
        return executeDownload(retryArgs, true);
      }

      console.warn(`[VidLoader Job ${job.id}] Download failed with code ${code}:`, stderrData);
      job.status = 'failed';
      job.error = cleanYtDlpError(stderrData) || 'Failed to download video. The content may be private, age-restricted, or removed by the platform.';
    });

    proc.on('error', (err) => {
      console.error(`[VidLoader Job ${job.id}] Process error:`, err);
      job.status = 'failed';
      job.error = err.message || 'Error occurred during media download.';
    });
  }

  executeDownload(initialArgs);
}
